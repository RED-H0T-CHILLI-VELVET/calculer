﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttn1 = new System.Windows.Forms.Button();
            this.inputBox = new System.Windows.Forms.TextBox();
            this.bttn2 = new System.Windows.Forms.Button();
            this.bttn3 = new System.Windows.Forms.Button();
            this.bttn4 = new System.Windows.Forms.Button();
            this.bttn5 = new System.Windows.Forms.Button();
            this.bttn6 = new System.Windows.Forms.Button();
            this.bttn7 = new System.Windows.Forms.Button();
            this.bttn8 = new System.Windows.Forms.Button();
            this.bttn9 = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            this.subBtn = new System.Windows.Forms.Button();
            this.multiBtn = new System.Windows.Forms.Button();
            this.divBtn = new System.Windows.Forms.Button();
            this.bttn0 = new System.Windows.Forms.Button();
            this.resolve = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttn1
            // 
            this.bttn1.Location = new System.Drawing.Point(351, 131);
            this.bttn1.Name = "bttn1";
            this.bttn1.Size = new System.Drawing.Size(75, 23);
            this.bttn1.TabIndex = 0;
            this.bttn1.Text = "1";
            this.bttn1.UseVisualStyleBackColor = true;
            this.bttn1.Click += new System.EventHandler(this.bttn1_Click);
            // 
            // inputBox
            // 
            this.inputBox.Location = new System.Drawing.Point(351, 44);
            this.inputBox.Name = "inputBox";
            this.inputBox.Size = new System.Drawing.Size(311, 22);
            this.inputBox.TabIndex = 1;
            // 
            // bttn2
            // 
            this.bttn2.Location = new System.Drawing.Point(432, 131);
            this.bttn2.Name = "bttn2";
            this.bttn2.Size = new System.Drawing.Size(75, 23);
            this.bttn2.TabIndex = 2;
            this.bttn2.Text = "2";
            this.bttn2.UseVisualStyleBackColor = true;
            this.bttn2.Click += new System.EventHandler(this.bttn2_Click);
            // 
            // bttn3
            // 
            this.bttn3.Location = new System.Drawing.Point(513, 131);
            this.bttn3.Name = "bttn3";
            this.bttn3.Size = new System.Drawing.Size(75, 23);
            this.bttn3.TabIndex = 3;
            this.bttn3.Text = "3";
            this.bttn3.UseVisualStyleBackColor = true;
            this.bttn3.Click += new System.EventHandler(this.bttn3_Click);
            // 
            // bttn4
            // 
            this.bttn4.Location = new System.Drawing.Point(351, 160);
            this.bttn4.Name = "bttn4";
            this.bttn4.Size = new System.Drawing.Size(75, 23);
            this.bttn4.TabIndex = 4;
            this.bttn4.Text = "4";
            this.bttn4.UseVisualStyleBackColor = true;
            this.bttn4.Click += new System.EventHandler(this.bttn4_Click);
            // 
            // bttn5
            // 
            this.bttn5.Location = new System.Drawing.Point(432, 160);
            this.bttn5.Name = "bttn5";
            this.bttn5.Size = new System.Drawing.Size(75, 23);
            this.bttn5.TabIndex = 5;
            this.bttn5.Text = "5";
            this.bttn5.UseVisualStyleBackColor = true;
            this.bttn5.Click += new System.EventHandler(this.bttn5_Click);
            // 
            // bttn6
            // 
            this.bttn6.Location = new System.Drawing.Point(513, 160);
            this.bttn6.Name = "bttn6";
            this.bttn6.Size = new System.Drawing.Size(75, 23);
            this.bttn6.TabIndex = 6;
            this.bttn6.Text = "6";
            this.bttn6.UseVisualStyleBackColor = true;
            this.bttn6.Click += new System.EventHandler(this.bttn6_Click);
            // 
            // bttn7
            // 
            this.bttn7.Location = new System.Drawing.Point(351, 189);
            this.bttn7.Name = "bttn7";
            this.bttn7.Size = new System.Drawing.Size(75, 23);
            this.bttn7.TabIndex = 7;
            this.bttn7.Text = "7";
            this.bttn7.UseVisualStyleBackColor = true;
            this.bttn7.Click += new System.EventHandler(this.bttn7_Click);
            // 
            // bttn8
            // 
            this.bttn8.Location = new System.Drawing.Point(432, 189);
            this.bttn8.Name = "bttn8";
            this.bttn8.Size = new System.Drawing.Size(75, 23);
            this.bttn8.TabIndex = 8;
            this.bttn8.Text = "8";
            this.bttn8.UseVisualStyleBackColor = true;
            this.bttn8.Click += new System.EventHandler(this.bttn8_Click);
            // 
            // bttn9
            // 
            this.bttn9.Location = new System.Drawing.Point(513, 189);
            this.bttn9.Name = "bttn9";
            this.bttn9.Size = new System.Drawing.Size(75, 23);
            this.bttn9.TabIndex = 9;
            this.bttn9.Text = "9";
            this.bttn9.UseVisualStyleBackColor = true;
            this.bttn9.Click += new System.EventHandler(this.bttn9_Click);
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(500, 291);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 23);
            this.clear.TabIndex = 10;
            this.clear.Text = "Limpar";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(231, 189);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(99, 23);
            this.addBtn.TabIndex = 12;
            this.addBtn.Text = "Soma";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // subBtn
            // 
            this.subBtn.Location = new System.Drawing.Point(231, 218);
            this.subBtn.Name = "subBtn";
            this.subBtn.Size = new System.Drawing.Size(99, 23);
            this.subBtn.TabIndex = 13;
            this.subBtn.Text = "Subtração";
            this.subBtn.UseVisualStyleBackColor = true;
            this.subBtn.Click += new System.EventHandler(this.subBtn_Click);
            // 
            // multiBtn
            // 
            this.multiBtn.Location = new System.Drawing.Point(231, 247);
            this.multiBtn.Name = "multiBtn";
            this.multiBtn.Size = new System.Drawing.Size(99, 23);
            this.multiBtn.TabIndex = 14;
            this.multiBtn.Text = "Multiplicação";
            this.multiBtn.UseVisualStyleBackColor = true;
            this.multiBtn.Click += new System.EventHandler(this.multiBtn_Click);
            // 
            // divBtn
            // 
            this.divBtn.Location = new System.Drawing.Point(231, 276);
            this.divBtn.Name = "divBtn";
            this.divBtn.Size = new System.Drawing.Size(99, 23);
            this.divBtn.TabIndex = 15;
            this.divBtn.Text = "Divisão";
            this.divBtn.UseVisualStyleBackColor = true;
            this.divBtn.Click += new System.EventHandler(this.divBtn_Click);
            // 
            // bttn0
            // 
            this.bttn0.Location = new System.Drawing.Point(432, 218);
            this.bttn0.Name = "bttn0";
            this.bttn0.Size = new System.Drawing.Size(75, 23);
            this.bttn0.TabIndex = 16;
            this.bttn0.Text = "0";
            this.bttn0.UseVisualStyleBackColor = true;
            this.bttn0.Click += new System.EventHandler(this.bttn0_Click);
            // 
            // resolve
            // 
            this.resolve.Location = new System.Drawing.Point(587, 291);
            this.resolve.Name = "resolve";
            this.resolve.Size = new System.Drawing.Size(75, 23);
            this.resolve.TabIndex = 11;
            this.resolve.Text = "Calcular";
            this.resolve.UseVisualStyleBackColor = true;
            this.resolve.Click += new System.EventHandler(this.resolve_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bttn0);
            this.Controls.Add(this.divBtn);
            this.Controls.Add(this.multiBtn);
            this.Controls.Add(this.subBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.resolve);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.bttn9);
            this.Controls.Add(this.bttn8);
            this.Controls.Add(this.bttn7);
            this.Controls.Add(this.bttn6);
            this.Controls.Add(this.bttn5);
            this.Controls.Add(this.bttn4);
            this.Controls.Add(this.bttn3);
            this.Controls.Add(this.bttn2);
            this.Controls.Add(this.inputBox);
            this.Controls.Add(this.bttn1);
            this.Name = "Form1";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttn1;
        private System.Windows.Forms.TextBox inputBox;
        private System.Windows.Forms.Button bttn2;
        private System.Windows.Forms.Button bttn3;
        private System.Windows.Forms.Button bttn4;
        private System.Windows.Forms.Button bttn5;
        private System.Windows.Forms.Button bttn6;
        private System.Windows.Forms.Button bttn7;
        private System.Windows.Forms.Button bttn8;
        private System.Windows.Forms.Button bttn9;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button subBtn;
        private System.Windows.Forms.Button multiBtn;
        private System.Windows.Forms.Button divBtn;
        private System.Windows.Forms.Button bttn0;
        private System.Windows.Forms.Button resolve;
    }
}

